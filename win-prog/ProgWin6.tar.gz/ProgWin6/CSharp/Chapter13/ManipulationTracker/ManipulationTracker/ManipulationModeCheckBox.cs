﻿using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;

namespace ManipulationTracker
{
    public class ManipulationModeCheckBox : CheckBox
    {
        public ManipulationModes ManipulationModes { set; get; }
    }
}
