﻿namespace PhotoScatter
{
    public enum ImageType
    {
        Thumbnail,
        Full,
        Transitioning
    }
}
