﻿using Windows.UI.Xaml.Controls;

namespace ClockRack
{
    public sealed partial class TimeZoneClock : UserControl
    {
        public TimeZoneClock()
        {
            this.InitializeComponent();
        }
    }
}
