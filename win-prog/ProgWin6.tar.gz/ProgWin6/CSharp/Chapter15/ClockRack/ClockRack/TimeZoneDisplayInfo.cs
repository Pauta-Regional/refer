﻿namespace ClockRack
{
    public struct TimeZoneDisplayInfo
    {
        public int Bias { set; get; }
        public string TimeZoneKey { set; get; }
        public string Display { set; get; }
    }
}
