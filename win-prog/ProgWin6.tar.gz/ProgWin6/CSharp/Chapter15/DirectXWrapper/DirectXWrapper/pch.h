//
// pch.h
// Header for standard system include files.
//

#pragma once

#include <wrl.h>
#include <d2d1_1.h>
#include <d3d11_1.h>
#include <dwrite.h>
#include <windows.ui.xaml.media.dxinterop.h>
