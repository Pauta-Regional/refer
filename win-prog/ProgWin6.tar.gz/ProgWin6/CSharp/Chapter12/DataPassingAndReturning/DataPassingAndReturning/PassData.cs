﻿using Windows.UI;

namespace DataPassingAndReturning
{
    public class PassData
    {
        public Color InitializeColor { set; get; }
    }
}
