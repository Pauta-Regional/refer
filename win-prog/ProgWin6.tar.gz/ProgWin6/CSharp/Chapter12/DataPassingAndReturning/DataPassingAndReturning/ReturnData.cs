﻿using Windows.UI;

namespace DataPassingAndReturning
{
    public class ReturnData
    {
        public Color ReturnColor { set; get; }
    }
}
